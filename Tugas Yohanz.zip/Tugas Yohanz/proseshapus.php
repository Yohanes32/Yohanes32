<?php 
//Menyambungkan file koneksi.php
include 'koneksi.php';
 $nama=$_GET['nama'];

  mysqli_query($dbconnect, "DELETE FROM kontak WHERE nama = '$nama' ");

  header('location:user.php');
?>
