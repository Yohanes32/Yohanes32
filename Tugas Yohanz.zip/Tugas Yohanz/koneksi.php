<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "phpcrud";

$dbconnect = mysqli_connect( "$host", "$username", "$password", "$db" );




?>