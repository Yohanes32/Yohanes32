<!doctype html>
<html lang="en">

<head>
  <title>Ulangan 1</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
</head>

<body class="dark-edition">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="black" data-image="./assets/img/sidebar-2.jpg">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          Yohanes Adi Setiawan
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="javascript:void(0)">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="user.php">
              <i class="material-icons">user</i>
              <p>User</p>
            </a>
          </li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:void(0)">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)">
                  <i class="material-icons">notifications</i>
                  <p class="d-lg-none d-md-block">
                    Notifications
                  </p>
                </a>
              </li>
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          
          <form action="prosesedit.php" method="POST">
             <?php
            include 'koneksi.php';
            $nama=$_GET['nama'];
            $query = mysqli_query($dbconnect,"SELECT * FROM kontak WHERE nama = '$nama' ");
            $tampil = mysqli_fetch_assoc($query);


?>
             <div class="col-md-8">
            <label for="validationServer01" class="form-label">ID</label>
            <input name="id" type="text" class="form-control" readonly="active" required value="<?php echo $tampil['id']?>">
          </div>
          <div class="col-md-8">
            <label for="validationServer01" class="form-label">Nama</label>
            <input name="nama" type="text" class="form-control" required value="<?php echo $tampil['nama']?>">
          </div>
            <div class="col-md-8">
            <label for="validationServer01" class="form-label">Email</label>
            <input name="email" type="email" class="form-control" required value="<?php echo $tampil['email']?>">
          </div>
            <div class="col-md-8">
            <label for="validationServer01" class="form-label">No Telepon</label>
            <input name="notelp" type="number" class="form-control" required value="<?php echo $tampil['notelp']?>">
          </div>
            <div class="col-md-8">
            <label for="validationServer01" class="form-label">Pekerjaan</label>
            <input name="pekerjaan" type="text" class="form-control" required value="<?php echo $tampil['pekerjaan']?>">
          </div>
          
        <button type="submit" class="btn">Kirim</button>

          </form>

       
</body>

</html>