<?php

 include 'koneksi.php';
 $nama= $_POST['nama'];
 $email= $_POST['email'];
 $notelp= $_POST['notelp'];
 $pekerjaan= $_POST['pekerjaan'];

  mysqli_query($dbconnect, "INSERT INTO kontak VALUES (NULL, '$nama','$email','$notelp','$pekerjaan')");
  header("location:user.php");

?>