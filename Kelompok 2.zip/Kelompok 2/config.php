<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "bioskop";

$dbconnect = new mysqli ("$host","$user","$pass","$db");


?>