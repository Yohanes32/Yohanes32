<?php
include 'config.php';
$email = $_POST["email"];
$password = $_POST["password"];

$query_sql = "SELECT * FROM `tb_admin` WHERE email = '$email' AND password = '$password'";

$result = mysqli_query($dbconnect, $query_sql);

if(mysqli_num_rows($result) > 0){
	    echo "<h1>Selamat Anda Berhasil Login</h1>";
	    header("location:index.php");
}else{
	echo '<script type="text/JavaScript">';
	echo 'alert("Maaf Username Atau Password Anda Salah")';
	echo '</script>';
	 
}
?>