<?php
include 'config.php';

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

mysqli_query($dbconnect, "INSERT INTO tb_admin (`id`, `username`,`email`, `password`) VALUES (NULL, '$username', '$email', '$password');");

header('location:login.php');
?>