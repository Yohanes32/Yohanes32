<?php

 include 'config.php';
 $id = $_POST['id'];
 $nama= $_POST['nama'];
 $harga= $_POST['harga'];
 $foto= $_POST['foto'];
 $durasi= $_POST['durasi'];

   mysqli_query($dbconnect, "UPDATE `tb_film` SET `nama` = '$nama',`harga` = '$harga',`foto` = '$foto',`durasi` = '$durasi' WHERE `id` = '$id'");
   header("location:index.php");

?>