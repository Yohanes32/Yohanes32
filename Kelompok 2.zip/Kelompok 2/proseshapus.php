<?php 
//Menyambungkan file koneksi.php
include 'config.php';
 $nama=$_GET['nama'];

  mysqli_query($dbconnect, "DELETE FROM tb_film WHERE nama = '$nama' ");

  header('location:index.php');
?>
